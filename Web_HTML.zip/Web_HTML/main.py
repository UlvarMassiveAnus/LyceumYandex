from flask import Flask, render_template, redirect, request
import os
from forms import SendPhotoForm
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config["SECRET_KEY"] = "SECRET_KEY"
app.config['UPLOAD_FOLDER'] = "./static/img"


@app.route('/carousel')
def carousel():
    return render_template('carousel.html')


@app.route('/', methods=['GET', 'POST'])
@app.route('/galery', methods=['GET', 'POST'])
def galery():
    form = SendPhotoForm()
    if request.method == 'POST':
        form.file.data.save(os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(form.file.data.filename)))
        return redirect('/galery')
    photo_galery = ['static/img/' + filename for filename in os.listdir('static/img')]
    return render_template('galery.html', galery=photo_galery, form=form)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
