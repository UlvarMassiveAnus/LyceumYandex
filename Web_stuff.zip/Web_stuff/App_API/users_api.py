import flask
import datetime
from data.db_session import create_session
from data.users import User

blueprint = flask.Blueprint('jobs_api', __name__, template_folder='templates')


@blueprint.route('/api/jobs')
def get_users():
    session = create_session()
    users = session.query(User).all()
    return flask.jsonify({
        "users": [item.to_dict(only=("id", "surname", "name", "age", "position",
                                     "speciality", "address", "email", "created_date")) for item in users]
    })


@blueprint.route('/api/jobs/<int:user_id>', methods=['GET'])
def get_one_job(user_id):
    session = create_session()
    user = session.query(User).get(user_id)
    return flask.jsonify({
        "users": [user.to_dict(only=("id", "surname", "name", "age", "position",
                                     "speciality", "address", "email", "created_date"))]
    })


@blueprint.route('/api/jobs', methods=['POST'])
def create_user():
    request = flask.request
    if not request.json:
        return flask.jsonify({'error': 'Empty request'})
    elif not all([key in request.json for key in ["surname", "name",
                                                  "age", "position",
                                                  "speciality", "address",
                                                  "email", "hashed_password"]]):
        return flask.jsonify({'error': 'Bad request'})
    session = create_session()
    user = User(
        email=request.json["email"],
        name=request.json["name"],
        surname=request.json["surname"],
        age=request.json["age"],
        position=request.json["position"],
        speciality=request.json["speciality"],
        address=request.json["address"],
    )
    user.set_password(request.json["hashed_password"])
    user.created_date = datetime.datetime.now()
    session.add(user)
    session.commit()
    return flask.jsonify({'success': 'OK'})


@blueprint.route('/api/jobs/<int:user_id>', methods=['DELETE'])
def delete_job(user_id):
    session = create_session()
    user = session.query(User).get(user_id)
    if not user:
        return flask.jsonify({'error': 'Not found'})
    session.delete(user)
    session.commit()
    return flask.jsonify({'success': 'OK'})


@blueprint.route('/api/jobs/<int:user_id>', methods=['PUT'])
def change_job(user_id):
    session = create_session()
    user = session.query(User).get(user_id)
    request = flask.request
    if not request.json:
        return flask.jsonify({'error': 'Empty request'})
    elif not all([key in request.json for key in ["surname", "name",
                                                  "age", "position",
                                                  "speciality", "address",
                                                  "email", "hashed_password"]]):
        return flask.jsonify({'error': 'Bad request'})
    user.surname = request.json['surname']
    user.name = request.json["name"]
    user.age = request.json["age"]
    user.position = request.json["position"]
    user.speciality = request.json["speciality"]
    user.address = request.json["address"]
    user.email = request.json["email"]
    user.set_password(request.json["hashed_password"])
    session.commit()
    return flask.jsonify({'success': 'OK'})