import flask
from data.db_session import create_session
from data.jobs import Jobs

blueprint = flask.Blueprint('jobs_api', __name__, template_folder='templates')


@blueprint.route('/api/jobs')
def get_jobs():
    session = create_session()
    jobs = session.query(Jobs).all()
    return flask.jsonify({
        "jobs": [item.to_dict(only=("id", "team_leader", "job", "work_size",
                                    "collaborators", "start_date", "end_date", "is_finished")) for item in jobs]
    })


@blueprint.route('/api/jobs/<int:job_id>', methods=['GET'])
def get_one_job(job_id):
    session = create_session()
    job = session.query(Jobs).get(job_id)
    return flask.jsonify({'job': job.to_dict(only=("id", "team_leader", "job", "work_size",
                                                   "collaborators", "start_date", "end_date", "is_finished"))})


@blueprint.route('/api/jobs', methods=['POST'])
def create_job():
    request = flask.request
    if not request.json:
        return flask.jsonify({'error': 'Empty request'})
    elif not all([key in request.json for key in ["team_leader", "job", "work_size",
                                                   "collaborators", "start_date",
                                                  "end_date", "is_finished"]]):
        return flask.jsonify({'error': 'Bad request'})
    session = create_session()
    a_job = Jobs(
        team_leader=request.json["team_leader"],
        job=request.json["job"],
        work_size=request.json["work_size"],
        collaborators=request.json["collaborators"],
        start_date=request.json["start_date"],
        end_date=request.json["end_date"],
        is_finished=request.json["is_finished"]
    )
    session.add(a_job)
    session.commit()
    return flask.jsonify({'success': 'OK'})


@blueprint.route('/api/jobs/<int:job_id>', methods=['DELETE'])
def delete_job(job_id):
    session = create_session()
    job = session.query(Jobs).get(job_id)
    if not job:
        return flask.jsonify({'error': 'Not found'})
    session.delete(job)
    session.commit()
    return flask.jsonify({'success': 'OK'})


@blueprint.route('/api/jobs/<int:job_id>', methods=['PUT'])
def change_job(job_id):
    session = create_session()
    a_job = session.query(Jobs).get(job_id)
    request = flask.request
    if not request.json:
        return flask.jsonify({'error': 'Empty request'})
    elif not all([key in request.json for key in ["team_leader", "job", "work_size",
                                                  "collaborators", "start_date",
                                                  "end_date", "is_finished"]]):
        return flask.jsonify({'error': 'Bad request'})
    a_job.team_leader = request.json['team_leader']
    a_job.job = request.json['job']
    a_job.work_size = request.json['work_size']
    a_job.collaborators = request.json['collaborators']
    a_job.start_date = request.json['start_date']
    a_job.end_date = request.json['end_date']
    a_job.is_finished = request.json['is_finished']
    session.commit()
    return flask.jsonify({'success': 'OK'})