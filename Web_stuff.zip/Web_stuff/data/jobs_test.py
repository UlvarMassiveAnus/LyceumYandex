from requests import get, post, delete

print(get('http://localhost:5000/api/v2/jobs').json())
print(get('http://localhost:5000/api/v2/jobs/1').json())
print(post('http://localhost:5000/api/v2/jobs').json())
print(post('http://localhost:5000/api/v2/jobs', json={'job': 'Заголовок'}).json())
print(post('http://localhost:5000/api/v2/jobs', json={'team_leader': 1,
                                                      'job': 'Разработка технологии добычи ресурсов на Марсе',
                                                      'work_size': 72,
                                                      'collaborators': '',
                                                      'start_date': '2029-03-05',
                                                      'end_date': '2029-03-08',
                                                      'is_finished': False
                                                      }).json())
print(delete('http://localhost:5000/api/v2/jobs/999').json())
print(delete('http://localhost:5000/api/v2/jobs/2').json())
