import sqlalchemy
from .db_session import SqlAlchemyBase


class KindsOfJob(SqlAlchemyBase):
    __tablename__ = 'kinds_of_job'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    kind = sqlalchemy.Column(sqlalchemy.String, nullable=True)