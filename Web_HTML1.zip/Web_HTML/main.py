from flask import Flask, render_template, redirect, request
import os
from forms import SendPhotoForm, LoadPhotoForm
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config["SECRET_KEY"] = "SECRET_KEY"
app.config['UPLOAD_FOLDER'] = "./static/img"


@app.route('/carousel')
def carousel():
    return render_template('carousel.html')


@app.route('/galery', methods=['GET', 'POST'])
def galery():
    form = SendPhotoForm()
    if request.method == 'POST':
        form.file.data.save(os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(form.file.data.filename)))
        return redirect('/galery')
    photo_galery = ['static/img/' + filename for filename in os.listdir('static/img')]
    return render_template('galery.html', galery=photo_galery, form=form)


@app.route('/', methods=['GET', 'POST'])
@app.route('/load_photo', methods=['GET', 'POST'])
def load_photo():
    form = LoadPhotoForm()
    if form.validate_on_submit():
        current_file = os.listdir('static/another images')
        if len(current_file):
            os.remove('static/another images/' + current_file[0])
        form.file.data.save(os.path.join('./static/another images', secure_filename(form.file.data.filename)))
    return render_template('load_photo.html',
                           image_flag=True,
                           image_source='static/another images/' + os.listdir('static/another images')[0],
                           form=form)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080)
