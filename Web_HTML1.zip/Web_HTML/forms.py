from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from wtforms.validators import DataRequired


class SendPhotoForm(FlaskForm):
    file = FileField('Заргузить фото', validators=[DataRequired()])
    submit = SubmitField('Отправить')


class LoadPhotoForm(FlaskForm):
    file = FileField('Приложите фотографию', validators=[DataRequired()])
    submit = SubmitField('Отправить')