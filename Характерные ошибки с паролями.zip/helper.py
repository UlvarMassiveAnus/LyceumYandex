def del_same_words():
    with open('data/top-9999-words.txt') as data:
        words = [word.strip('\n') for word in data]

    for word in words:
        for cword in range(len(words)):
            if word in words[cword] and word != words[cword]:
                words[cword] += '1'

    words = [word for word in words if word[-1] != '1']

    with open('data/top-9999-words.txt', 'w') as data:
        data.write('\n'.join(words))