from main import check_password
from helper import del_same_words

del_same_words()

with open('data/top 10000 passwd.txt') as data:
    passwords = [line.strip('\n') for line in data.readlines()]
with open('data/top-9999-words.txt') as data:
    words = [line.strip('\n') for line in data.readlines()]


ec = {'LengthError': 0, 'LetterError': 0, 'DigitError': 0, 'SequenceError': 0, 'WordError': 0}

for password in passwords:
    for error in check_password(password, words):
        ec[error.__name__] += 1

print('\n'.join([k + ' - ' + str(ec[k]) for k in sorted(ec.keys())]))