import re
from exeptions import LengthError, LetterError, DigitError, SequenceError, WordError


class PasswordCheck:
    def __init__(self, password):
        self.password = password
        self.type_parse()

    def len_check(self):
        assert len(self.password) > 8

    def letters_check(self):
        assert any([re.search("[A-Z]",
                              self.password),
                    re.search("[ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮЁ]",
                              self.password)])
        assert any([re.search("[йцукенгшщзхъфывапролджэячсмитьбюё]",
                              self.password),
                    re.search("[a-z]", self.password)])

    def numbers_check(self):
        assert re.search("[0-9]", self.password)

    def keyboard_check(self):
        keys = {1: ['q', 'й'], 2: ['w', 'ц'], 3: ['e', 'у'],
                4: ['r', 'к'], 5: ['t', 'е'], 6: ['y', 'н'],
                7: ['u', 'г'], 8: ['i', 'ш'], 9: ['o', 'щ'],
                10: ['p', 'з'], 11: ['х'], 12: ['ъ'],
                15: ['a', 'ф'], 16: ['s', 'ы'], 17: ['d', 'в'],
                18: ['f', 'а'], 19: ['g', 'п'], 20: ['h', 'р'],
                21: ['j', 'о'], 22: ['k', 'л'], 23: ['l', 'д'],
                24: ['ж'], 25: ['э'], 26: ['ё'],
                29: ['z', 'я'], 30: ['x', 'ч'], 31: ['c', 'с'],
                32: ['v', 'м'], 33: ['b', 'и'],
                34: ['n', 'т'], 35: ['m', 'ь'], 36: ['б'], 37: ['ю'],
                40: '!@#$%^&*(){}[]:;\'\"\\|\t\n<>,./?-_+=~`1234567890'}
        parsed_password = []
        for s in self.password.lower():
            for key in keys.keys():
                if s in keys[key]:
                    parsed_password.append(key)
        prev = [parsed_password[0], parsed_password[1]]
        for s in parsed_password[2:]:
            prev.append(s)
            if prev[0] == prev[1] - 1 and prev[0] == prev[2] - 2:
                raise AssertionError
            prev = [prev[1], prev[2]]

    def type_parse(self):
        assert type(self.password) in {int, str}
        self.password = str(self.password)

    def words_check(self, words):
        for word in words:
            assert not re.search(word, self.password.lower())


def check_password(password, words):
    pc = PasswordCheck(password)
    occurred_errors = []
    try:
        pc.len_check()
    except AssertionError:
        occurred_errors.append(LengthError)
    try:
        pc.letters_check()
    except AssertionError:
        occurred_errors.append(LetterError)
    try:
        pc.numbers_check()
    except AssertionError:
        occurred_errors.append(DigitError)
    try:
        pc.keyboard_check()
    except AssertionError:
        occurred_errors.append(SequenceError)
    try:
        pc.words_check(words)
    except AssertionError:
        occurred_errors.append(WordError)
    return occurred_errors
